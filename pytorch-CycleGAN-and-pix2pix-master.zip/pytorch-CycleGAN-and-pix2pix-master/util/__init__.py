"""This package includes a miscellaneous collection of useful helper functions."""
